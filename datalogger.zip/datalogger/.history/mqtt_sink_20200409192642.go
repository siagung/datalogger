package main

import (
	"fmt"
	"os"
	"time"
)

//MqttSink : MqttSink
type MqttSink struct {
	path        string
	file        *os.File
	fileType    uint
	fifo        chan *Point
	maxAge      time.Duration
	lastSave    time.Time
	recordCount uint
}

//NewMqttSink : Returns a new console sink.
func NewMqttSink(fifoSize uint) (cs *MqttSink, err error) {
	if fifoSize == 0 {
		fifoSize = 300
	}

	cs = &ConsoleSink{
		fifo: make(chan *Point, fifoSize),
	}

	go cs.writer()

	return
}

//Save : Buffers points for later disk write. Points are rejected when the fifo is full.
func (fs *MqttSink) Save(points []*Point) (acceptedCount uint) {
	for _, p := range points {
		if len(fs.fifo) < cap(fs.fifo) {
			fs.fifo <- p
			acceptedCount++
		}
	}

	return
}

func (cs *MqttSink) writer() {
	var p *Point

	for {
		p = <-cs.fifo

		// drop nil points
		if p == nil {
			continue
		}

		fmt.Printf("timestamp: %v, label: %s, value: %v\n",
			p.Timestamp, p.Label, p.Value)
	}

	return
}

/*
func Init() {

	fmt.Println("pubsub : Raspberry Pi Pub/Sub initializing...")
	optsPub := MQTT.NewClientOptions()
	//optsPub.AddBroker("tcp://iot.eclipse.org:1883")
	optsPub.AddBroker("tcp://m14.cloudmqtt.com:14205")
	optsPub.SetUsername("htmbxcyz")     // TODO
	optsPub.SetPassword("rH2_IZj43nDy") // TODO
	optsPub.SetClientID("rasp-pi-go")
	optsPub.SetCleanSession(false)
	optsPub.SetDefaultPublishHandler(func(client MQTT.Client, msg MQTT.Message) {
		fmt.Println("SetDefaultPublishHandler : ", msg.Topic(), string(msg.Payload()))
	})

	fmt.Println("pubsub : Raspberry Pi MQTT broker configured")

	clientPub := MQTT.NewClient(optsPub)
	if tokenPub := clientPub.Connect(); tokenPub.Wait() && tokenPub.Error() != nil {
		panic(tokenPub.Error())
	}

	gpio.PubGreenLedStatus = func(ledMapJSON interface{}) {
		tokenPub := clientPub.Publish("plain/led/status/green", 0, false, ledMapJSON)
		tokenPub.Wait()
	}

	gpio.PubBlueLedStatus = func(ledMapJSON interface{}) {
		tokenPub := clientPub.Publish("secure/led/status/blue", 0, false, ledMapJSON)
		tokenPub.Wait()
	}

	gpio.PubRedLedStatus = func(ledMapJSON interface{}) {
		tokenPub := clientPub.Publish("secure/led/status/red", 0, false, ledMapJSON)
		tokenPub.Wait()
	}

	if tokenPub := clientPub.Subscribe("secure/led/action/red", 0, gpio.SubRedLedAction); tokenPub.Wait() && tokenPub.Error() != nil {
		fmt.Println(tokenPub.Error())
		os.Exit(1)
	}

	fmt.Println("pubsub : Raspberry Pi Pub/Sub callbacks registered")

}
*/
