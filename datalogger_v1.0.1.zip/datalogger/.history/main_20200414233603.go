package main

import (
	"fmt"
	"os"
	"time"

	_ "github.com/dimiro1/banner/autoload"
	"github.com/fatih/color"
)

// const (
// 	InfoColor    = "\033[1;34m%s\033[0m"
// 	NoticeColor  = "\033[1;36m%s\033[0m"
// 	WarningColor = "\033[1;33m%s\033[0m"
// 	ErrorColor   = "\033[1;31m%s\033[0m"
// 	DebugColor   = "\033[0;36m%s\033[0m"
// )

// var (
// 	Black   = Color("\033[1;30m%s\033[0m")
// 	Red     = Color("\033[1;31m%s\033[0m")
// 	Green   = Color("\033[1;32m%s\033[0m")
// 	Yellow  = Color("\033[1;33m%s\033[0m")
// 	Purple  = Color("\033[1;34m%s\033[0m")
// 	Magenta = Color("\033[1;35m%s\033[0m")
// 	Teal    = Color("\033[1;36m%s\033[0m")
// 	White   = Color("\033[1;37m%s\033[0m")
// )

func main() {
	//var confPath string
	// isEnabled := true
	// isColorEnabled := true
	// banner.Init(colorable.NewColorableStdout(), isEnabled, isColorEnabled, bytes.NewBufferString("My Custom Banner"))

	var conf *Configuration
	var err error
	var ticker *time.Ticker
	var poller *Poller
	var pollers []*Poller
	var sink Sink
	var sinks []Sink
	var points []*Point

	// flag.StringVar(&confPath, "conf", "path to configuration file", "conf.json")
	// flag.Parse()
	// confPath = "D:/AGUNG/AppGo/lat/datalogger/conf.json"
	// if confPath == "" {
	// 	fmt.Println("no configuration file given, aborting.")
	// 	os.Exit(1)
	// }
	//fmt.Println("no configuration file given, aborting.")
	conf, err = Load("conf.json")
	if err != nil {
		cp := color.New(color.FgRed).Add(color.Underline)
		cp.Printf("failed to load configuration file: %v\n", err)
		os.Exit(1)
	}

	// create and configure data sinks
	for idx, sc := range conf.Sinks {
		switch sc.Type {
		case "json":
			sink, err = NewFileSink(sc.URL, FILE_TYPE_JSON, sc.FifoSize,
				time.Duration(sc.MaxAgeMs)*time.Millisecond)

		case "csv":
			sink, err = NewFileSink(sc.URL, FILE_TYPE_CSV, sc.FifoSize,
				time.Duration(sc.MaxAgeMs)*time.Millisecond)

		case "influxdb":
			sink, err = NewInfluxDBSink(sc.URL, sc.FifoSize, 0,
				time.Duration(sc.MaxAgeMs)*time.Millisecond)

		case "console":
			sink, err = NewConsoleSink(sc.FifoSize)

		case "mqtt":
			sink, err = NewMqttSink(sc.URL, sc.ClientID, sc.FifoSize, 0, sc.CleanSession, sc.Topic, sc.NoTopic, time.Duration(sc.MaxAgeMs)*time.Millisecond)

		default:
			fmt.Printf("unsupported sink type '%v'\n", sc.Type)
			os.Exit(2)
		}

		if err != nil {
			fmt.Printf("failed to create sink #%v, skipping it: %v\n",
				idx, err)
			continue
		}

		sinks = append(sinks, sink)
	}

	if len(sinks) == 0 {
		fmt.Printf("no active sink, bailing out\n")
		os.Exit(2)
	}

	// create and configure pollers
	for idx := range conf.Pollers {
		poller, err = NewPoller(conf.Pollers[idx])
		if err != nil {
			cp := color.New(color.FgRed).Add(color.Underline)
			cp.Printf("failed to create poller #%v, skipping it: %v\n",
				idx, err)
			continue
		}

		pollers = append(pollers, poller)
	}

	if len(pollers) == 0 {
		fmt.Printf("no active poller, bailing out\n")
		os.Exit(2)
	}

	ticker = time.NewTicker(conf.DispatchRate)
	c1 := color.New(color.FgHiBlue).Add(color.Underline)
	c1a := color.New(color.FgHiYellow).Add(color.Underline)
	c1.Print("PT. Multi Kreasi Lestarindo")
	fmt.Print(" - ")
	c1a.Println("www.multikreasilestarindo.com")
	fmt.Println(" ")
	c := color.New(color.FgGreen).Add(color.Underline)
	c.Printf("Started modbus datalogger with %v pollers and %v sinks\n",
		len(pollers), len(sinks))
	// fmt.Printf("Started modbus datalogger with %v pollers and %v sinks\n",
	// 	len(pollers), len(sinks))

	for {
		<-ticker.C

		// collect readings from all pollers
		for _, poller := range pollers {
			points = append(points, poller.Points()...)
		}

		if len(points) <= 0 {
			continue
		}

		// pass on the collected values to all sinks
		for _, sink := range sinks {
			sink.Save(points)
		}

		points = points[:0]
	}

	//return
}
