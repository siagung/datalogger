package main

import (
	"bytes"
	"fmt"
	"log"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"time"

	mqtt "github.com/eclipse/paho.mqtt.golang"
)

//MqttSink : MqttSink
type MqttSink struct {
	host         string
	clientID     string
	fifo         []*Point
	lock         sync.Mutex
	batchSize    uint
	bufferSize   uint
	cleanSession bool
	topic        string
	pushInterval time.Duration
	clientOpt    *mqtt.ClientOptions
}

//NewMqttSink : Returns a new console sink.
func NewMqttSink(host string, clientID string, bufferSize uint, batchSize uint, cleanSession bool, topic string, pushInterval time.Duration) (ms *MqttSink, err error) {
	// if fifoSize == 0 {
	// 	fifoSize = 300
	// }

	// buffer 100k points by default
	if bufferSize == 0 {
		bufferSize = 100000
	}

	// default to pushing 1k points at once
	if batchSize == 0 {
		batchSize = 1000
	}

	ms = &MqttSink{
		fifo:         make([]*Point, 0),
		host:         host,
		clientID:     clientID,
		cleanSession: cleanSession,
		topic:        topic,
		pushInterval: pushInterval,
		batchSize:    batchSize,
		bufferSize:   bufferSize,
	}

	go ms.writer()

	return
}

//Save : Buffers points for later disk write. Points are rejected when the fifo is full.
func (ms *MqttSink) Save(points []*Point) (acceptedCount uint) {
	var pointCount uint

	pointCount = uint(len(points))
	if pointCount == 0 {
		return
	}

	ms.lock.Lock()

	acceptedCount = ms.bufferSize - uint(len(ms.fifo))

	if acceptedCount > pointCount {
		acceptedCount = pointCount
	}

	if acceptedCount > 0 {
		ms.fifo = append(ms.fifo, points[0:acceptedCount]...)
	}
	ms.lock.Unlock()

	if acceptedCount != pointCount {
		fmt.Printf("Mqtt sink: dropped %v points out of %v\n",
			pointCount-acceptedCount, pointCount)
	}

	return
}

// Periodically reads points from the internal buffer, serializes them and pushes
// them to influxdb API.
func (ms *MqttSink) writer() {
	var batch []*Point
	var batchSize uint
	var ticker *time.Ticker
	var buf bytes.Buffer
	var res *http.Response
	var err error

	ticker = time.NewTicker(ms.pushInterval)

	for {
		// clear the send buffer
		buf.Reset()

		<-ticker.C

		ms.lock.Lock()
		// determine how many points to grab
		batchSize = uint(len(ms.fifo))
		if batchSize > ms.batchSize {
			batchSize = ms.batchSize
		}

		// grab batchSize points
		batch = ms.fifo[0:batchSize]
		ms.lock.Unlock()

		if batchSize == 0 {
			continue
		}

		// serialize the batch
		ms.serialize(&buf, batch)

		// post the serialized payload to influxdb
		res, err = ms.client.Post(
			fmt.Sprintf("%s&precision=ms", ms.url), "text", &buf)
		if err != nil {
			fmt.Printf("failed to perform influxdb POST request: %v\n", err)
			continue
		}
		res.Body.Close()

		if res.StatusCode != http.StatusNoContent {
			fmt.Printf("influxdb POST request failed with status code: %d\n",
				res.StatusCode)
			continue
		}

		// free points which have been successfully pushed
		is.lock.Lock()
		is.fifo = is.fifo[batchSize:]
		is.lock.Unlock()
	}

	return
}

// Turns points into influxdb line protocol entries.
func (is *MqttSink) serialize(buf *bytes.Buffer, points []*Point) {
	var idx int
	var fieldName string

	for _, p := range points {
		if p == nil {
			continue
		}

		// locate the last dot
		idx = strings.LastIndex(p.Label, ".")

		// if there is no dot or if the dot is either at the beginning or at the end
		// of the label, we can't split on it: drop the point.
		if idx < 1 || idx == len(p.Label)-1 {
			fmt.Printf("discarding point with label '%s': cannot split on '.'\n",
				p.Label)
			continue
		}

		// use the last token as field name
		fieldName = p.Label[idx+1 : len(p.Label)]

		buf.WriteString(
			fmt.Sprintf("%s %s=%v %v\n",
				p.Label[0:idx], fieldName,
				p.Value, p.Timestamp.UnixNano()/1e6))
	}

	return
}

func connect(clientID string, uri *url.URL) mqtt.Client {
	opts := createClientOptions(clientID, uri)
	client := mqtt.NewClient(opts)
	token := client.Connect()
	for !token.WaitTimeout(3 * time.Second) {
	}
	if err := token.Error(); err != nil {
		log.Fatal(err)
	}
	return client
}

func createClientOptions(clientID string, uri *url.URL) *mqtt.ClientOptions {
	opts := mqtt.NewClientOptions()
	opts.AddBroker(fmt.Sprintf("tcp://%s", uri.Host))
	opts.SetUsername(uri.User.Username())
	password, _ := uri.User.Password()
	opts.SetPassword(password)
	opts.SetClientID(clientID)
	return opts
}

// func listen(uri *url.URL, topic string) {
// 	client := connect("sub", uri)
// 	client.Subscribe(topic, 0, func(client mqtt.Client, msg mqtt.Message) {
// 		fmt.Printf("* [%s] %s\n", msg.Topic(), string(msg.Payload()))
// 	})
// }

// func (cs *MqttSink) writer() {
// 	var p *Point

// 	for {
// 		p = <-cs.fifo

// 		// drop nil points
// 		if p == nil {
// 			continue
// 		}

// 		fmt.Printf("mqtt: %v, label: %s, value: %v\n",
// 			p.Timestamp, p.Label, p.Value)
// 	}

// 	return
// }

/*
func Init() {

	fmt.Println("pubsub : Raspberry Pi Pub/Sub initializing...")
	optsPub := MQTT.NewClientOptions()
	//optsPub.AddBroker("tcp://iot.eclipse.org:1883")
	optsPub.AddBroker("tcp://m14.cloudmqtt.com:14205")
	optsPub.SetUsername("htmbxcyz")     // TODO
	optsPub.SetPassword("rH2_IZj43nDy") // TODO
	optsPub.SetClientID("rasp-pi-go")
	optsPub.SetCleanSession(false)
	optsPub.SetDefaultPublishHandler(func(client MQTT.Client, msg MQTT.Message) {
		fmt.Println("SetDefaultPublishHandler : ", msg.Topic(), string(msg.Payload()))
	})

	fmt.Println("pubsub : Raspberry Pi MQTT broker configured")

	clientPub := MQTT.NewClient(optsPub)
	if tokenPub := clientPub.Connect(); tokenPub.Wait() && tokenPub.Error() != nil {
		panic(tokenPub.Error())
	}

	gpio.PubGreenLedStatus = func(ledMapJSON interface{}) {
		tokenPub := clientPub.Publish("plain/led/status/green", 0, false, ledMapJSON)
		tokenPub.Wait()
	}

	gpio.PubBlueLedStatus = func(ledMapJSON interface{}) {
		tokenPub := clientPub.Publish("secure/led/status/blue", 0, false, ledMapJSON)
		tokenPub.Wait()
	}

	gpio.PubRedLedStatus = func(ledMapJSON interface{}) {
		tokenPub := clientPub.Publish("secure/led/status/red", 0, false, ledMapJSON)
		tokenPub.Wait()
	}

	if tokenPub := clientPub.Subscribe("secure/led/action/red", 0, gpio.SubRedLedAction); tokenPub.Wait() && tokenPub.Error() != nil {
		fmt.Println(tokenPub.Error())
		os.Exit(1)
	}

	fmt.Println("pubsub : Raspberry Pi Pub/Sub callbacks registered")

}
*/
